let calendar = document.querySelector('.calendar');

const month_names = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

isLeapYear = (year) => {
    return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
};

getFebDays = (year) => {
    return isLeapYear(year) ? 29 : 28;
};

generateCalendar = (month, year) => {
    let calendar_days = calendar.querySelector('.calendar-days');
    let calendar_header_year = calendar.querySelector('#year');
    let days_of_month = [31, getFebDays(year), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

    calendar_days.innerHTML = '';

    let currDate = new Date();
    if (month > 11 || month < 0) month = currDate.getMonth();
    if (!year) year = currDate.getFullYear();

    // Check if the current month and year match December 2023 
    if (!((month === 11 && year === 2023) || (month === 0 && year === 2024))) {
        calendar.style.display = 'none';
        return;
    } else {
        calendar.style.display = 'block';
    }

    let curr_month = `${month_names[month]}`;
    month_picker.innerHTML = curr_month;
    calendar_header_year.innerHTML = year;

    // get first day of month
    let first_day = new Date(year, month, 1);

    for (let i = 0; i <= days_of_month[month] + first_day.getDay() - 1; i++) {
        let day = document.createElement('div');
        if (i >= first_day.getDay()) {
            day.classList.add('calendar-day-hover');
            day.innerHTML = i - first_day.getDay() + 1;
            day.innerHTML += `<span></span>
                            <span></span>
                            <span></span>
                            <span></span>`;

            if (i - first_day.getDay() + 1 === currDate.getDate() && year === currDate.getFullYear() && month === currDate.getMonth()) {
                day.classList.add('curr-date');
            }

            day.onclick = () => {
                promptForReminder(`${year}-${month + 1}-${i - first_day.getDay() + 1}`);
            };
        }
        calendar_days.appendChild(day);
    }
};

let month_list = calendar.querySelector('.month-list');

month_names.forEach((e, index) => {
    let month = document.createElement('div');
    month.innerHTML = `<div data-month="${index}">${e}</div>`;
    month.querySelector('div').onclick = () => {
        month_list.classList.remove('show');
        curr_month.value = index;
        generateCalendar(index, curr_year.value);
    };
    month_list.appendChild(month);
});

let month_picker = calendar.querySelector('#month-picker');

month_picker.onclick = () => {
    month_list.classList.add('show');
};

let currDate = new Date();

let curr_month = { value: currDate.getMonth() };
let curr_year = { value: currDate.getFullYear() };

generateCalendar(curr_month.value, curr_year.value);

document.querySelector('#prev-year').onclick = () => {
    --curr_year.value;
    generateCalendar(curr_month.value, curr_year.value);
    updateMonthPicker(curr_month.value);
};

document.querySelector('#next-year').onclick = () => {
    ++curr_year.value;
    generateCalendar(curr_month.value, curr_year.value);
    updateMonthPicker(curr_month.value);
};

// Function to update the month picker text
function updateMonthPicker(monthIndex) {
    let curr_month = `${month_names[monthIndex]}`;
    month_picker.innerHTML = curr_month;
}

// Function to prompt user for a reminder
function promptForReminder(date) {
    const reminderMessage = prompt(`Enter a reminder for ${date}`);
    if (reminderMessage) {
        addReminder(date, reminderMessage);
    }
}

// Function to add a reminder
function addReminder(date, message) {
    const reminderList = document.getElementById('reminder-list');
    const reminderItem = document.createElement('li');
    reminderItem.innerHTML = `<div class="reminder" onclick="showReminder('${message}')">${date}: ${message}</div>`;
    reminderList.appendChild(reminderItem);
}

// Function to show a reminder (you can customize this)
function showReminder(message) {
    alert(`Reminder: ${message}`);
}
